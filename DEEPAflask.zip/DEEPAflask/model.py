#import libraries
import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

#load data to python environment
df=pd.read_csv('salarydata.csv')

df.drop(['capital-gain','capital-loss','education-num'], axis = 1,inplace = True)

#outlier handing age & hours-per-week
Q1=np.percentile(df['age'],25,interpolation='midpoint')
Q2=np.percentile(df['age'],50,interpolation='midpoint')
Q3=np.percentile(df['age'],75,interpolation='midpoint')
IQR=Q3-Q1

low_limit=Q1-1.5*IQR
up_limit=Q3+1.5*IQR

outlier=[]

for x in df['age']:
 if((x>up_limit) or (x<low_limit)):
   outlier.append(x)
indA=df['age']>up_limit
indA1=df.loc[indA].index
df.drop(indA1,inplace=True)
indB=df['age']<low_limit
indB1=df.loc[indB].index
df.drop(indB1,inplace=True)
Q1=np.percentile(df['hours-per-week'],25,interpolation='midpoint')
Q2=np.percentile(df['hours-per-week'],50,interpolation='midpoint')
Q3=np.percentile(df['hours-per-week'],75,interpolation='midpoint')
IQR=Q3-Q1

low_limit=Q1-1.5*IQR
up_limit=Q3+1.5*IQR



for x in df['hours-per-week']:
 if((x>up_limit) or (x<low_limit)):
    outlier.append(x)

indA=df['hours-per-week']>up_limit
indA1=df.loc[indA].index

df.drop(indA1,inplace=True)

indB=df['hours-per-week']<low_limit
indB1=df.loc[indB].index

df.drop(indB1,inplace=True)

label=LabelEncoder()

df['workclass']=label.fit_transform(df['workclass'])
df['education']=label.fit_transform(df['education'])
df['occupation']=label.fit_transform(df['occupation'])
df['sex']=label.fit_transform(df['sex'])
df['salary']=label.fit_transform(df['salary'])
df['race']=label.fit_transform(df['race'])
df['native-country']=label.fit_transform(df['native-country'])
df['marital-status']=label.fit_transform(df['marital-status'])
df['relationship']=label.fit_transform(df['relationship'])
x=df.drop(columns=['salary'],axis=1)
y=df['salary']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=0)
from sklearn import preprocessing
stand=preprocessing.StandardScaler()
x=stand.fit_transform

from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier(learning_rate=0.01, n_estimators=1750,max_depth=5, min_samples_split=2, min_samples_leaf=1, subsample=1,max_features='sqrt', random_state=10)
gb.fit(x_train,y_train)
y_pred = gb.predict(x_test)


#Fitting the model
y.predict=label.inverse_transform(y_pred)
#Saving the model to disk
pickle.dump(gb,open('model.pkl','wb') )